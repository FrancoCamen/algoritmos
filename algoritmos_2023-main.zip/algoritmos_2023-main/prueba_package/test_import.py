
# from funciones.mi_modulo_de_funciones_en_python import suma
from ..funciones.mi_modulo_de_funciones_en_python import suma

print(suma(1, 2))