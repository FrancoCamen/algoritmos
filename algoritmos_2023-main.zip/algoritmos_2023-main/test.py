# algo para probar pull
#! IMPORTAR MODULOS

#import math
# from math import sqrt, tan, cos
# import mi_modulo_de_funciones_en_python as func
# from mi_modulo_de_funciones_en_python import suma, tan as mi_tan

# import mi_modulo_de_funciones_en_python
#print(math.sqrt(9))
# print(suma(1, 3), mi_tan())


# from funciones.mi_modulo_de_funciones_en_python import suma, resta

# print(resta(5, 3))


from quicksort import data

for valor in data:
    print(valor)