# from quicksort import data


# for value in data:
#     print(value['nombre'], value['edad'])


from prueba_package import test_import