

print('hola desde mi modulo')

def tan():
    print('mi calculo de la tangente')
    pass

def suma(num1, num2):
    """ recibe dos numero y retorna la suma"""
    return num1 + num2

def resta(num1, num2):
    ''' recibe dos enteros y retorna la diferencia'''
    return num1 - num2

def producto(num1, num2):
    return num1 * num2

print('chauuuuuuu')